TODO LIST: 6/1/2016

New Features:
----------------
Documentation
Update README
Code Comments
Visible Version Status Number in UI
Show the Average on the Nullifium graph

Bugfixes:
----------------
Find out why sometimes it does maps for a one extra prestige than it should.
Bone Portal messes with graphs / Importing a savedgame in progress produces bad graphs


Improvements:
----------------
Void Map Farming
    - based on how much damage you do rather than your health/survival

Programming/CodeWise:
----------------------
Rewrite the automaps way of deciding/picking/buying/running maps.
While doing this, comment out the extra *2 from the baseDamage
Also while doing this, determine more refined rules for entering the 3 modes: want dmg/want health/farming
